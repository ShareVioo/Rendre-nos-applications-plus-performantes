# wevioo-rabbitMq-websocket-demo

This project contain two other projects (Back symfony 4 & Front Angular 8)

Software Required:
- RabbitMq 
- MailCatcher